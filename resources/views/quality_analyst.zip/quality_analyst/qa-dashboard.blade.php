<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Dashboard
            <small>Control panel</small>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="callout callout- ">
                    <h3></h3>

                    {{--<h4>This panel is used for attendance use only.</h4>--}}
                </div>
            </div>

        </div>
    </section>
</div>