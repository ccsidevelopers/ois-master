<!DOCTYPE html>
<html>
    @include('layouts.includes.headerplugins')

    <link rel="stylesheet" href="https://cdn.datatables.net/rowreorder/1.2.0/css/rowReorder.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.dataTables.min.css">

    <body class="skin-red layout-top-nav">
        <header class="main-header">
            <nav class="navbar navbar-static-top">
                <div class="container-fluid">
                    <div class="logo">
                        <img src="{{ asset('dist\img\ccsi-logo.png') }}">
                    </div>

                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                            <i class="fa fa-bars"></i>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse" id="navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="#" id="seeOnlineAppModal">See Online Application</a></li>
                            {{--<li><a href="" data-toggle="modal" data-target="#modal-contact-us">Contact Us</a></li>--}}
                        </ul>
                    </div>
                    <!-- /.navbar-collapse -->
                </div>
                <!-- /.container-fluid -->
            </nav>
        </header>

        <div class="box">
            <div class="col-md-12">
                <div class="box-body">
                    <div class="panel panel-success">
                        <div class="panel-heading" style="text-align: center">
                            <h4>
                                <label for="">PERSONAL HISTORY STATEMENT</label>
                            </h4>
                        </div>
                        <div class="panel-body">
                            <div id="smartwizard" style="padding-left : 5%; padding-right: 5%">
                                <ul class="nav">
                                    <li>
                                        <a class="nav-link" href="#step-1">
                                            I. PERSONAL DETAILS
                                        </a>
                                    </li>
                                    <li>
                                        <a class="nav-link" href="#step-2">
                                            II. WORK EXPERIENCE
                                        </a>
                                    </li>
                                    <li>
                                        <a class="nav-link" href="#step-3">
                                            III. AFFILIATIONS/ CONNECTIONS
                                        </a>
                                    </li>
                                    <li>
                                        <a class="nav-link" href="#step-4">
                                            IV. OPTIONAL(OTHERS)
                                        </a>
                                    </li>
                                    <li>
                                        <a class="nav-link" href="#step-5">
                                            V. ATTACHMENTS/DOCUMENTS
                                        </a>
                                    </li>
                                </ul>

                                <div class="tab-content changeTabContent" style="height : 100%; ">
                                    <div id="step-1" class="tab-pane" role="tabpanel">
                                        <div class="row" style="padding-top : 40px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-8">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Personal Details</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <p style="color : red " id="redToShowNecessary" hidden>*Please fill up necessary fields</p>
                                                        <p style="color : red" id="redToShowSSS" hidden>*Please enter valid SSS number</p>
                                                        <div class = "row" style="padding-top: 20px;">
                                                            <div class = "form-group col-md-3">
                                                                <label>Last Name:</label><small style="color: red;"> (Required Field)</small>
                                                                <input type="text"
                                                                       class = "form-control save_this_data required_personal toRed" what="personal_details" id = "acct_last" name = "acct_last">
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label>First Name:</label><small style="color: red;"> (Required Field)</small>
                                                                <input type="text"
                                                                       class = "form-control save_this_data required_personal toRed" what="personal_details" id = "acct_first" name = "acct_first">
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label>Middle Name:</label><small style="color: orange;"> (<Optional></Optional> Field)</small>
                                                                <input type="text"
                                                                       class = "form-control save_this_data " what="personal_details " id = "acct_middle" name = "acct_middle">
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label>Suffix Name:</label><small style="color: orange;"> (Optional Field)</small>
                                                                <input type="text"
                                                                       class = "form-control save_this_data" what="personal_details" id = "acct_suffix" name = "acct_suffix">
                                                            </div>
                                                        </div>

                                                        <div class = "row">
                                                            <div class="form-group col-md-3">
                                                                <label>Birthdate:</label><small style="color: red;"> (Required Field)</small>
                                                                <input type="date" class = "form-control save_this_data required_personal toRed" what="personal_details" id="acct_birthdate_full" name="acct_birthdate_full">
                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label>Age:</label><small style="color: red;"> (Required Field)</small>
                                                                <input type="number" class = "form-control save_this_data required_personal toRed" what="personal_details" id="acct_age" name="acct_age" disabled>
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label>Gender:</label><small style="color: orange;"> (Optional Field)</small>
                                                                <select class="acct_gender form-control save_this_data toDash" what="personal_details"  id="acct_gender" name="acct_gender">
                                                                    <option value =
                                                                            "-">-</option>
                                                                    <option value =
                                                                            "Male">Male</option>
                                                                    <option value =
                                                                            "Female">Female</option>
                                                                </select>
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label>Marital Status:</label><small style="color: orange;"> (Optional Field)</small>
                                                                <select class="acct_marital_status form-control save_this_data toDash" what="personal_details" name="acct_marital_status" id="acct_marital_status">
                                                                    <option value ="-">-</option>
                                                                    <option value ="Single">Single</option>
                                                                    <option value ="Married">Married</option>
                                                                    <option value ="Widowed">Widowed</option>
                                                                    <option value ="Divorced">Divorced</option>
                                                                    <option value ="Separated">Separated</option>
                                                                </select>
                                                            </div>

                                                        </div>

                                                        <div hidden id="if_married_check">
                                                            <div class="row" style="padding-top : 10px; padding-bottom : 10px;">
                                                                <div class="form-group col-md-4">
                                                                    <label>Maiden Last Name:</label><small style="color: orange;"> (Optional Field)</small>
                                                                    <input type="text" class = "form-control save_this_data" what="personal_details" id = "acct_maiden_last_name" name = "acct_maiden_last_name">
                                                                </div>
                                                                <div class="form-group col-md-4">
                                                                    <label>Maiden First Name:</label><small style="color: orange;"> (Optional Field)</small>
                                                                    <input type="text" class = "form-control save_this_data" what="personal_details" id = "acct_maiden_first_name" name = "acct_maiden_first_name">
                                                                </div>
                                                                <div class="form-group col-md-4">
                                                                    <label>Maiden Middle Name:</label><small style="color: orange;"> (Optional Field)</small>
                                                                    <input type="text" class = "form-control save_this_data" what="personal_details" id = "acct_maiden_middle_name" name = "acct_maiden_middle_name">
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class = "row">
                                                            <div class = "form-group col-md-3">
                                                                <label>Birth Place:</label>
                                                                <input type="text" class="form-control save_this_data" what="personal_details" id="acct_birth_place" name="acct_birth_place">
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label>Religion:</label>
                                                                <input type="text" class="form-control save_this_data" what="personal_details" id="acct_religion" name="acct_religion">

                                                            </div>
                                                            <div class="form-group col-md-3">
                                                                <label>Tel/CP no.</label>
                                                                <input type="number" class="form-control save_this_data" what="personal_details" id="acct_tel_cp" name="acct_tel_cp">
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label>SSS no: <small style="color : red;">*Required: 10-digit</small></label>
                                                                <input type="number" class="form-control save_this_data toRed" what="personal_details" id="acct_sss" name="acct_sss" >
                                                            </div>
                                                        </div>
                                                        <div class = "row">

                                                        </div>


                                                        <div class="box-header with-border" style="padding : 0; margin-top : 20px;">
                                                            <b>Present Address</b>
                                                        </div>
                                                        <div class ="row">
                                                            <input class="save_this_data form-control required_personal" type="hidden" id="acct_present_address_provID" what="personal_details"  name="acct_present_address_provID" muniVal = "acct_present_muni">
                                                            <input class="save_this_data  form-control required_personal" type="hidden" id="acct_present_address_muniID" what="personal_details" name="acct_present_address_muniID" muniVal = "acct_present_province">
                                                            <div class="form-group col-md-5">
                                                                <label>Unit #, Bldg/Street, Subd/Brgy.</label><small style="color: red;"> (Required Field)</small>
                                                                <input type="text" class="form-control save_this_data required_personal toRed" placeholder="" id="acct_present_address" what="personal_details" name="present_address">
                                                            </div>
                                                            <div class="form-group col-md-3" data-toggle="tooltip" title="Please select city/municipality suggestion list appear below the textbox, this will be auto generate the province">

                                                                <label>City/Municipality</label><small style="color: red;"> (Required Field)</small>
                                                                <input type="text" class="form-control ui-autocomplete-input cityMuniProvClass toRed" placeholder="" id="acct_present_muni" name="municipality" autocomplete="off">
                                                            </div>
                                                            <div class="form-group col-md-4"><label>Province</label><small style="color: red;"> (Auto Generated)</small><span id="loading_present_Prov"></span>
                                                                <input type="text" class="form-control cityMuniProvClass toRed" placeholder="" id="acct_present_province" name="province" disabled="">
                                                            </div>
                                                        </div>

                                                        <input type="checkbox" id="bi_check_same_address" value="same_address">
                                                        <strong>
                                                            Check if "PermanentAddress" same as "Present Address"
                                                        </strong>

                                                        <div class="box-header with-border" style="padding : 0; margin-top : 20px;">
                                                            <b>Permanent Address</b>
                                                        </div>

                                                        <div class ="row">
                                                            <input class="save_this_data form-control required_personal" type="hidden" id="acct_perma_address_provID" what="personal_details" name="acct_perma_address_provID" muniVal = "acct_perma_muni">
                                                            <input class="save_this_data form_control required_personal" type="hidden" id="acct_perma_address_muniID" what="personal_details" name="acct_perma_address_muniID" muniVal = "acct_perma_province">
                                                            <div class="form-group col-md-5">
                                                                <label>Unit #, Bldg/Street, Subd/Brgy.</label><small style="color: red;"> (Required Field)</small>
                                                                <input type="text" class="form-control toDisable save_this_data required_personal toEnableAdd toRed" placeholder="" id="acct_perma_address" name="perma_address">
                                                            </div>
                                                            <div class="form-group col-md-3" data-toggle="tooltip" title="Please select city/municipality suggestion list appear below the textbox, this will be auto generate the province">
                                                                <label>City/Municipality</label><small style="color: red;"> (Reuired Field)</small>
                                                                <input type="text" class="form-control ui-autocomplete-input toDisable cityMuniProvClass toEnableAdd toRed" placeholder="" id="acct_perma_muni" name="municipality" autocomplete="off"></div>
                                                            <div class="form-group col-md-4">
                                                                <label>Province</label><small style="color: red;"> (Auto Generated)</small><span id="loading_permanent_Prov"></span>
                                                                <input type="text" class="form-control toClear cityMuniProvClass toRed" placeholder="" id="acct_perma_province" name="province" disabled="">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="box box-primary">
                                                    <div class = "row" style="padding-top : 40px">
                                                        <div class="col-md-1"></div>
                                                        <div class="col-md-10">
                                                            <form id="form1" runat="server">
                                                                <img id = "uploadedImgView" style = "width: 100% ; height: 100%; border:5px solid #000;" src = "{{asset('user_profile_pictures/default3.jpg')}}" />
                                                            </form>
                                                        </div>
                                                        <div class="col-md-1"></div>
                                                    </div>
                                                    <div class = "row" style="padding-top : 20px;">
                                                        <div class="col-md-12">
                                                            <input type='file' id="cancelImgUploaded" /><button id = "cancelImg" class="pull-right" style="margin-bottom: 10px">Cancel</button>
                                                        </div>
                                                    </div>
                                                    <div class = "row" style="padding-top : 10px;">
                                                        <div class="col-md-12">
                                                            <label>Email:</label><small style="color: red;"> (Required Field)</small>
                                                            <input type="text" class = "form-control save_this_pesonal_email required_personal toRed" what="personal_details" id = "personal_email" name = "personal_email">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                        <div class="row" style="padding-top : 40px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-8">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Marital History (if applicable)</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" style="padding-top : 20px">
                                                            <div class = "form-group col-md-8">
                                                                <label for="">Name of Spouse:</label>
                                                                <input type="text" class="form-control save_this_data" what="marital_history" id="acct_spouse_name" name="acct_spouse_name" >
                                                            </div>
                                                            <div class = "form-group col-md-4">
                                                                <label for="">Telephone/ Mobile No.:</label>
                                                                <input type="number" class="form-control save_this_data" what="marital_history" id="acct_spouse_present_tel_cp"  name="acct_spouse_present_tel_cp">
                                                            </div>
                                                        </div>

                                                        <div class = "row" style="padding-top : 10px;">
                                                            <div class = "form-group col-md-12">
                                                                <h4>Children: <button class="btn btn-xs btn-success" id="btnAddAcctChildren"><i class="fa fa-plus"></i></button></h4>
                                                                <table class="display table-hover responsive"  style="width : 100%" id="childrenDatatable">
                                                                    <thead>
                                                                    <tr>
                                                                        <th>Name</th>
                                                                        <th>Date of Birth</th>
                                                                        <th>Place of Birth</th>
                                                                        <th></th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody id = "acct_table_children" class="tableClearAll">
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3"></div>
                                        </div>
                                        <div class="row" style="padding-top : 40px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-8">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Family History and Information</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-4">
                                                                <label for="">Father's Full Name:</label>
                                                                <input type="text" class="form-control save_this_data" what="family_history" id="acct_father_full" name="acct_father_full">
                                                            </div>
                                                            <div class = "form-group col-md-2">
                                                                <label for="">Age:</label>
                                                                <input type="number" class="form-control save_this_data" what="family_history" id="acct_father_age" name="acct_father_age">
                                                            </div>
                                                            <div class = "form-group col-md-4">
                                                                <label for="">Occupation:</label>
                                                                <input type="text" class="form-control save_this_data2" what="family_history" id="acct_father_occupation" name="acct_father_occupation">
                                                            </div>
                                                            <div class = "form-group col-md-2">
                                                                <label for="">Telephone/ Mobile No.:</label>
                                                                <input type="number" class="form-control save_this_data" what="family_history" id="acct_father_tel" name="acct_father_tel">
                                                            </div>

                                                        </div>
                                                        <div class = "row">
                                                            <div class = "form-group col-md-4">
                                                                <label for="">Mother's Full Name:</label>
                                                                <input type="text" class="form-control save_this_data" what="family_history" id="acct_mother_full" name="acct_mother_full">
                                                            </div>
                                                            <div class = "form-group col-md-2">
                                                                <label for="">Age:</label>
                                                                <input type="number" class="form-control save_this_data" what="family_history" id="acct_mother_age"  name="acct_mother_age">
                                                            </div>
                                                            <div class = "form-group col-md-4">
                                                                <label for="">Occupation:</label>
                                                                <input type="text" class="form-control save_this_data2" what="family_history" id="acct_mother_occupation" name="acct_mother_occupation">
                                                            </div>
                                                            <div class = "form-group col-md-2">
                                                                <label for="">Telephone/ Mobile No.:</label>
                                                                <input type="text" class="form-control save_this_data" what="family_history" id="acct_mother_tel" name="acct_mother_tel">
                                                            </div>
                                                        </div>

                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-12">
                                                                <h4>Siblings: <button class="btn btn-xs btn-success" id="btnAddSiblings"><i class="fa fa-plus"></i></button></h4>
                                                                    <table class="display table-hover responsive"  style="width : 100%" id="siblingsnDatatable">
                                                                        <thead>
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Age</th>
                                                                            <th>Address</th>
                                                                            <th>Occupation</th>
                                                                            <th></th>
                                                                        </tr>
                                                                        </thead>
                                                                        <tbody id="acct_table_siblings" class="tableClearAll">
                                                                        </tbody>
                                                                    </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" style="padding-top : 40px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-8">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Educational Background</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row">
                                                            <div class = "form-group col-md-3">
                                                                <label for="">Secondary (Name of School):</label>
                                                                <textarea class="form-control save_this_data" rows="2" id="acct_secondary_name" what="educ_background" name="acct_secondary_name"></textarea>
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label for="">Location:</label>
                                                                <textarea class="form-control save_this_data" rows="2" id="acct_secondary_loc" what="educ_background" name="acct_secondary_loc"></textarea>
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label for="">Inclusive Dates of Attendance:</label>
                                                                <input type="text" class="form-control save_this_data" id="acct_secondary_inclusive" what="educ_background" name="acct_secondary_inclusive">
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label for="">Year Graduated/Degree:</label>
                                                                <input type="text" class="form-control save_this_data" id="acct_secondary_year" what="educ_background" name="acct_secondary_year">
                                                            </div>
                                                        </div>
                                                        <div class = "row">
                                                            <div class = "form-group col-md-3">
                                                                <label for="">College (Name of School):</label>
                                                                <textarea class="form-control save_this_data" rows="2" id="acct_college" what="educ_background"  name="acct_college"></textarea>
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label for="">Location:</label>
                                                                <textarea class="form-control save_this_data" rows="2" id="acct_college_loc" what="educ_background" name="acct_college_loc"></textarea>
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label for="">Inclusive Dates of Attendance:</label>
                                                                <input type="text" class="form-control save_this_data" id="acct_college_inclusive" what="educ_background" name="acct_college_inclusive">
                                                            </div>
                                                            <div class = "form-group col-md-3">
                                                                <label for="">Year Graduated/Degree:</label>
                                                                <input type="text" class="form-control save_this_data"  id="acct_college_year" what="educ_background" name="acct_college_year">
                                                            </div>
                                                        </div>
                                                        <div class = "row" style="padding-top : 10px;">
                                                            <div class = "form-group col-md-12">
                                                                <label for="">Other Schools Attended, Dates of Attendance, and Cerificate / Degree Earned:</label>
                                                                <textarea class="form-control save_this_data" rows="2" id="acct_other_schools" what="educ_background" name="acct_other_schools"></textarea>
                                                            </div>
                                                        </div>
                                                        <div class = "row" >
                                                            <div class = "form-group col-md-12">
                                                                <label for="">Civil Service Eligibility, if any, and other similar qualification/s required.
                                                                    State rating & Professional Regulations Commision License No. if applicable:</label>
                                                                <textarea class="form-control save_this_data" rows="2" id="acct_civil_service" what="educ_background" name="acct_civil_service"></textarea>
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" style="padding-top : 20px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-8">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Places of Residence since Birth</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-12">
                                                                <h4>List down residences: <button class="btn btn-xs btn-success" id="btnAddResidences"><i class="fa fa-plus"></i></button></h4>
                                                                <table class="display table-hover responsive"  style="width : 100%" id="residencesDatatable">
                                                                    <thead>
                                                                    <tr>
                                                                        <th>Inclusive Dates</th>
                                                                        <th>Complete Address</th>
                                                                        <th></th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody id="acct_table_residences" class="tableClearAll">
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" style="padding-top : 20px">
                                            <div class="col-md-12">
                                                <button class="btn btn-primary btn-md pull-right btnnextTab" style="margin-left : 10px">Next <i class="glyphicon glyphicon-triangle-right"></i> </button>
                                                <button class="btn btn-default btn-md pull-right btnpreviousTab" disabled><i class="glyphicon glyphicon-triangle-left"></i> Previous</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="step-2" class="tab-pane" role="tabpanel">
                                        <div class="row" style="padding-top : 40px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-10">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Work Experience</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-12">
                                                                <h4>List down changes in position/designation for the last 10 years to present: <button class="btn btn-xs btn-success" id="btnAddWorkExp"><i class="fa fa-plus"></i></button></h4>
                                                                    <table  class="display table-hover responsive"  style="width : 100%" id="workExpDatatable">
                                                                        <thead>
                                                                        <tr>
                                                                            <th>Date Started</th>
                                                                            <th>Date Ended</th>
                                                                            <th></th>
                                                                            <th>Position</th>
                                                                            <th>Employee No. <small style="color : orange">(optional)</small></th>
                                                                            <th>Employer Address </th>
                                                                            <th>Employer Contact No</th>
                                                                            <th>Name of Supervisor</th>
                                                                            <th>Contact number of Supervisor</th>
                                                                            <th>Reason for Leaving</th>
                                                                            <th></th>
                                                                        </tr>
                                                                        </thead>
                                                                        <tbody id="acct_table_work_exp" class="tableClearAll">
                                                                        </tbody>
                                                                    </table>
                                                            </div>
                                                        </div>
                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-12">
                                                                <label for="">Have you ever been dismissed or forced to resign from a position?
                                                                    <input type="text" class="save_this_data" id="acct_dismissed" what="work_experience" name="acct_dismissed"> If yes, explain:</label>

                                                                <textarea class="form-control save_this_data" rows="2" id="acct_dismissed_reason" what="work_experience" name="acct_dismissed_reason"></textarea>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                        <div class="row" style="padding-top : 20px">
                                            <div class="col-md-12" >
                                                <button class="btn btn-primary btn-md pull-right btnnextTab" style="margin-left : 10px">Next <i class="glyphicon glyphicon-triangle-right"></i> </button>
                                                <button class="btn btn-default btn-md pull-right btnpreviousTab" disabled><i class="glyphicon glyphicon-triangle-left"></i> Previous</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="step-3" class="tab-pane" role="tabpanel">
                                        <div class="row" style="padding-top : 40px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-10">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Character Reference </div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-12">
                                                                <h4>Character References / Professional References: <small style="color : red"> Required(5)</small> <button class="btn btn-xs btn-success" id="btnAddCharacter"><i class="fa fa-plus"></i></button></h4>

                                                                    <table  class="display table-hover responsive"  style="width : 100%" id="characDatatable">
                                                                        <thead>
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Position Employment</th>
                                                                            <th>Company Address</th>
                                                                            <th>Email Address <small style="color : orange">(optional)</small></th>
                                                                            <th>Telephone No./Mobile No.</th>
                                                                            <th></th>
                                                                        </tr>
                                                                        </thead>
                                                                        <tbody id="acct_table_character" class="tableClearAll">
                                                                        </tbody>
                                                                    </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2"></div>
                                        </div>
                                        <div class="row" style="padding-top : 20px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-10">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Membership in Civic/Religious Organization</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-12">
                                                                <h4>List down organizations: <button class="btn btn-xs btn-success" id="btnAddOrg"><i class="fa fa-plus"></i></button></h4>
                                                                <table class="display table-hover responsive"  style="width : 100%" id="orgsDatatable">
                                                                    <thead>
                                                                    <tr>
                                                                        <th>Name of Organization</th>
                                                                        <th>Date of Membership</th>
                                                                        <th>Position</th>
                                                                        <th></th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody id="acct_table_org" class="tableClearAll">
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                        <div class="row" style="padding-top : 20px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-10">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Trainings Attended</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-12">
                                                                <h4>List down trainings: <button class="btn btn-xs btn-success" id="btnAddTraining"><i class="fa fa-plus"></i></button></h4>
                                                                <table class="display table-hover responsive"  style="width : 100%" id="trainingsDatatables" >
                                                                    <thead>
                                                                    <tr>
                                                                        <th>Nature/Title</th>
                                                                        <th>Conducted by</th>
                                                                        <th>Year - Taken</th>
                                                                        <th></th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody id="acct_training_table" class="tableClearAll">
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                        <div class="row" style="padding-top : 20px">
                                            <div class="col-md-12">
                                                <button class="btn btn-primary btn-md pull-right btnnextTab" style="margin-left : 10px">Next <i class="glyphicon glyphicon-triangle-right"></i> </button>
                                                <button class="btn btn-default btn-md pull-right btnpreviousTab" disabled><i class="glyphicon glyphicon-triangle-left"></i> Previous</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="step-4" class="tab-pane" role="tabpanel">
                                        <div class="row" style="padding-top : 20px;">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-10">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Credit References</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" style="padding-top : 20px;">
                                                            <div class = "form-group col-md-12">
                                                                <h4>List of Credit Card/s: <button class="btn btn-xs btn-success" id="btnAddCredit"><i class="fa fa-plus"></i></button></h4>
                                                                <table class="display table-hover responsive"  style="width : 100%" id="credsDatatables" >
                                                                    <thead>
                                                                    <tr>
                                                                        <th>Credit Card</th>
                                                                        <th>Number</th>
                                                                        <th>Credit Limit/Status</th>
                                                                        <th>Expiry Date</th>
                                                                        <th></th>
                                                                    </tr>
                                                                    </thead>
                                                                    <tbody id="acct_credit_table" class="tableClearAll">
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                        <div class="row" style="padding-top : 20px">
                                            <div class="col-md-12">
                                                <button class="btn btn-primary btn-md pull-right btnnextTab" style="margin-left : 10px">Next <i class="glyphicon glyphicon-triangle-right"></i> </button>
                                                <button class="btn btn-default btn-md pull-right btnpreviousTab" disabled><i class="glyphicon glyphicon-triangle-left"></i> Previous</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="step-5" class="tab-pane" role="tabpanel">
                                        <div class="row" style="padding-top : 20px;">
                                            <div class="col-md-2"></div>
                                            <div class="col-md-8">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Attachment/s</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" >
                                                            <div class="col-md-12">
                                                                <div class="row" style="padding-top : 20px">
                                                                    <div class="form-group col-md-6">
                                                                        <label>Attachment 1(TOR)</label>
                                                                        <input class="acct_attached_file" type="file" id="attach1">
                                                                    </div>
                                                                    <div class="form-group col-md-6"><label>Attachment 2(Application Form)</label>
                                                                        <input class="acct_attached_file" type="file" id="attach2">
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="form-group col-md-6">
                                                                        <label>Attachment 3(COE)</label>
                                                                        <input class="acct_attached_file" type="file" id="attach3">
                                                                    </div>
                                                                    <div class="form-group col-md-6">
                                                                        <label>Attachment 4(Others)</label>
                                                                        <input class="acct_attached_file" type="file" id="attach4">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row" style="padding-top : 20px;">
                                            <div class="col-md-2"></div>
                                            <div class="col-md-8">
                                                <div class="box box-primary">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Additional Attachment/s</div>
                                                    </div>
                                                    <div class="box-body">
                                                        <div class = "row" >
                                                            <div class="col-md-12">
                                                                <a class="btn btn-app" id="clicktoAddAdditionalAttach">
                                                                    <i class="fa fa-plus"></i> Add
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="row" style="padding-top : 20px" id="divToFillAdditionalAttach">

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-2"></div>
                                        </div>



                                        <div class="row" style="padding-top : 20px">
                                            <div class="col-md-12">
                                                <button class="btn btn-primary btn-md pull-right btnnextTab" style="margin-left : 10px">Next <i class="glyphicon glyphicon-triangle-right"></i> </button>
                                                <button class="btn btn-default btn-md pull-right btnpreviousTab" disabled><i class="glyphicon glyphicon-triangle-left"></i> Previous</button>
                                            </div>
                                        </div>
                                        <div class="row" style="padding-top : 40px">
                                            <div class="col-md-12">
                                                <button class="btn btn-success btn-md pull-right submitDataInfo" ><i class="fa fa-fw fa-eye"></i> Review Application</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modal-contact-us">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h3 class="modal-title" style = "text-align: left">Contact Us</h3>
                    </div>
                    <div class="modal-body">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="col-md-8">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="">Name <small style="color:red">(Required)</small></label>
                                                    <input type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="">E-mail address <small style="color:red">(Required)</small></label>
                                                    <input type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="">Subject</label>
                                                    <input type="text" class="form-control">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="">Message</label>
                                                    <textarea name="" id="" rows="5" class="form-control" style="resize: none"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="panel-footer" style="text-align: right">
                                            <button class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="box box-danger">
                                        <div class="box-title" style="text-align: center">
                                            <h3 class="box-title">Wanna Talk?</h3>
                                            <h4 class="box-title">Drop by and say hi...</h4>
                                        </div>
                                        <div class="bod-body" style="padding-top: 10px">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="">Manila Office:</label>
                                                    <p>Unit 2503 & 2504 25/F Summit One Tower, 530 Shaw Blvd,
                                                        Mandaluyong City, Philippines
                                                        HR/Admin: 781-3265  Finance:  239-5462</p>
                                                </div>
                                                <div class="col-md-12">
                                                    <label for="">Cebu Office:</label>
                                                    <p>Unit 7, Dolores Place, Acacia St.,
                                                        Brgy. Kamputhaw, Cebu City
                                                        (032) 266-0835 / (032) 412-0182</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>

                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="modal fade" id="modal-see-online-transaction">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <center><h4>Tracking/Application Information</h4></center>
                            </div>
                            <div class="panel-body" style="padding-top : 20px; "\>
                                <br>
                                <div class="row showThisFalseBoolTrack"  hidden>
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8">
                                        <label for="">Tracking No.:</label>
                                        <input type="text" class="form-control" id="trackIdInfo" placeholder="Copy and paste the tracking number here......">
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>

                                <div class="row showThisTrueBoolTrack" hidden>
                                    <div class="col-md-2"></div>
                                    <div class="col-md-8">
                                        <label for="">Status:</label> <span id="direct_status_view" style="font-weight: bold" class="classViewTransac"></span><br>
                                        <label for="">Applicant Name:</label> <span id="direct_name"  class="classViewTransac"></span><br>
                                        <label for="">Address:</label> <span id="direct_address"  class="classViewTransac"></span><br>
                                        <label for="">Municipality :</label> <span id="direct_muni"  class="classViewTransac"></span><br>
                                        <label for="">Province:</label> <span id="direct_province"  class="classViewTransac"></span><br>
                                        <label for="">Transaction ID:</label> <span id="tr_id_view" style="font-weight: bold"  class="classViewTransac"></span>
                                    </div>
                                    <div class="col-md-2"></div>
                                </div>

                            </div>
                            <div class="panel-footer">
                                <div class="row">
                                    <div class="col-md-12">
                                 <span class="pull-right showThisTrueBoolTrack" hidden>
                                    <button class="btn btn-info" id="btnsearchNewTrack">Back</button>
                                </span>
                                        <span class="pull-right showThisFalseBoolTrack" hidden>
                                    <button class="btn btn-success" id="btnSearchTrackNow"><i class="fa fa-fw fa-send"></i>Search</button>
                                </span>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>


        <div class="modal fade" id="modal-loading-direct-endorse">
            <div class="modal-dialog" >
                <div class="modal-content">
                    <div class="modal-header" style="background-color: #d9edf7">
                        <h4 class="modal-title" >Information</h4>
                    </div>
                    <div class="modal-body">
                        <p style = "text-align: center; padding-top : 20px; font-size: large">Please wait while sending application
                            <span style = "padding-right : 5px;" ><img src= "{{asset('dist/img/loading.gif')}}" style = "width: 7%"></span>
                        </p>

                        <div class = "row" style = "padding-top : 15px;">
                            <div class = "col-md-2"></div>
                            <div class = "col-md-8">
                                <span id="ulPercentage_direct_en"></span>
                                <div id="progressbar_direct_en" hidden></div>
                            </div>
                            <div class = "col-md-2"></div>
                        </div>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>


        <div class="modal modal-success fade" id="modal-success-direct">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 style="text-align : center">Successfully Submitted Application</h3>
                    </div>
                    <div class="modal-body">

                        <div class="row" style="padding-top: 10px">
                            <div class="col-md-12">
                                <h4 style="text-align : center">TRACKING/APPLICATION NO:  <span id="trackDirectId"></span></h4>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-outline pull-right" id="btnCloseModalClear">Close</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="modal fade" id="modal-review-endorse-direct">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header" style="background-color: #d9edf7">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 style="text-align: center" >Confirmation of details</h4>
                    </div>
                    <div class="modal-body" style=" height: 790px; overflow: scroll; padding : 5px;">

                        <div class="row" style="padding-top: 20px;">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h4 style="text-align: center">Personal Details</h4>
                                    </div>
                                    <div class="box-body">
                                        <div class = "row" style="padding-top: 20px;">
                                            <div class="col-md-4"></div>
                                            <div class="col-md-4">
                                                <form id="form2" runat="server">
                                                    <img id = "uploadedImgModalView" style = "width: 100% ; height: 100%; border:5px solid #000;" src = "{{asset('user_profile_pictures/default3.jpg')}}" />
                                                </form>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px;">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-body">
                                        <div class = "row" style="padding-top: 20px;">
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Email Address:</label>
                                                        <p id="personal_email_view"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Last Name:</label>
                                                        <p id="lastnameView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>First Name:</label>
                                                        <p id="firstameView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Middle Name:</label>
                                                        <p id="midnameView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Suffix Name:</label>
                                                        <p id="suffixnameView"></p>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Birthdate:</label>
                                                        <p id="birthdateView"></p>

                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Age:</label>
                                                        <p id="ageView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Gender:</label>
                                                        <p id="genderView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Marital Status:</label>
                                                        <p id="maritalStatView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Maiden Last Name:</label>
                                                        <p id="maidenLastnameView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Maiden First Name:</label>
                                                        <p id="maidenFirstnameView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Maiden Middle Name:</label>
                                                        <p id="maidenMidnameView"></p>
                                                    </div>
                                                </div>


                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Birth Place:</label>
                                                        <p id="birthplaceView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Religion:</label>
                                                        <p id="religionView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Tel/CP no.:</label>
                                                        <p id="telCpView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>SSS no:</label>
                                                        <p id="sssView"></p>
                                                    </div>
                                                </div>

                                                <div class="row">

                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Present Adress</div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Unit #, Bldg/Street, Subd/Brgy.:</label>
                                                        <p id="presentAddressView"></p>

                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>City/Municipality:</label>
                                                        <p id="presentCityView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Province:</label>
                                                        <p id="presentProvinceView"></p>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="box-header with-border">
                                                        <div class = "box-title">Permanent Address</div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Unit #, Bldg/Street, Subd/Brgy.:</label>
                                                        <p id="permaAddressView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>City/Municipality:</label>
                                                        <p id="permaCityView"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class = "col-md-12">
                                                        <label>Province:</label>
                                                        <p id="permaProvinceView"></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h4 style="text-align: center">Marital History</h4>
                                    </div>
                                    <div class="box-body">
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Name of Spouse:</label>
                                                <p id="spouseNameView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Telephone/ Mobile No.:</label>
                                                <p id="spouseContactView"></p>
                                            </div>
                                        </div>

                                        <div class = "row" style="padding-top : 10px;">
                                            <div class = "col-md-12">
                                                <h4>Children:</h4>
                                                <table class="display table-hover responsive"  style="width : 100%" id="chidrenTableView">
                                                    <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Date of Birth</th>
                                                        <th>Place of Birth</th>
                                                    </tr>
                                                    </thead>
                                                </table>
                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px;">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h4  style="text-align: center">Family History and Information</h4>
                                    </div>
                                    <div class="box-body">
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Father's Full Name:</label>
                                                <p id="FatherFullView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Father's Age:</label>
                                                <p id="FatherAgeView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Father's Occupation:</label>
                                                <p id="FatherOccupation"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Father's Tel/CP no.:</label>
                                                <p id="FatherCPView"></p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Mother's Full Name:</label>
                                                <p id="MotherFullView"></p>

                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Mother's Age:</label>
                                                <p id="MotherAgelView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Mother's Occupation:</label>
                                                <p id="MotherOccupation"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Mother's Tel/CP no.:</label>
                                                <p id="MotherCPView"></p>
                                            </div>
                                        </div>

                                        <div class = "row" style="padding-top : 20px;">
                                            <div class = "col-md-12">
                                                <h4>Siblings: </h4>
                                                <table class="display table-hover responsive"  style="width : 100%" id="sibsTableView">
                                                    <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Age</th>
                                                        <th>Address</th>
                                                        <th>Occupation</th>
                                                    </tr>
                                                    </thead>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h4  style="text-align: center">Educational Background</h4>
                                    </div>
                                    <div class="box-body">
                                        <div class="row">
                                            <div class="box-header with-border">
                                                <div class = "box-title">Secondary</div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Secondary (Name of School):</label>
                                                <p id="secondaryNameView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Location:</label>
                                                <p id="secondartLocationView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Inclusive Dates of Attendance:</label>
                                                <p id="secondaryInclusiveView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Year Graduated/Degree:</label>
                                                <p id="secondaryYearGradView"></p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="box-header with-border">
                                                <div class = "box-title">Tertiary</div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>College (Name of School):</label>
                                                <p id="collegeNameView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Location:</label>
                                                <p id="collegeLocationView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Inclusive Dates of Attendance:</label>
                                                <p id="collegeInclusiveView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Year Graduated/Degree:</label>
                                                <p id="collegeYearGradView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Other Schools Attended, Dates of Attendance, and Cerificate / Degree Earned:</label>
                                                <p id="otherSchoolsView"></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class = "col-md-12">
                                                <label>Civil Service Eligibility, if any, and other similar qualification/s required.
                                                    State rating & Professional Regulations Commision License No. if applicable:</label>

                                                <p id="civilServiceView"></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px" >
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h4 style="text-align : center;">Places of Residence since Birth</h4>
                                    </div>
                                    <div class="box-body">
                                        <div class = "row" style="padding-top : 20px;">
                                            <div class = "form-group col-md-12">
                                                <h4>Residence/s:</h4>
                                                    <table class="display table-hover responsive"  style="width : 100%" id="residenceTableView">
                                                        <thead>
                                                        <tr>
                                                            <th>Inclusive Dates</th>
                                                            <th>Complete Address</th>
                                                        </tr>
                                                        </thead>
                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <h4 style="text-align : center">Work Experience</h4>
                                    </div>
                                    <div class="box-body">
                                        <div class = "row">
                                            <div class = "col-md-12">
                                                <h4>List of position/designation for the last 10 years to present:</h4>

                                                    <table class="display table-hover responsive"  style="width : 100%" id="workTableView">
                                                        <thead>
                                                        <tr>
                                                            <th>Date Started</th>
                                                            <th>Date Ended</th>
                                                            <th>Present/-</th>
                                                            <th>Designation</th>
                                                            <th>Employee No.</th>
                                                            <th>Employer Address </th>
                                                            <th>Employer Contact No</th>
                                                            <th>Name of Supervisor</th>
                                                            <th>Contact number of Supervisor</th>
                                                            <th >Reason for Leaving</th>
                                                        </tr>
                                                        </thead>
                                                    </table>

                                            </div>
                                        </div>
                                        <div class = "row">
                                            <div class = "col-md-12">
                                                <label for="">Have you ever been dismissed or forced to resign from a position?
                                                    If yes, explain:</label>

                                                <p><span id="forceResignView"></span>. <span id="forceResignReasonView"></span></p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px;">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <div class = "box-title">Character Reference </div>
                                    </div>
                                    <div class="box-body">
                                        <div class = "row" style="padding-top : 20px;">
                                            <div class = "form-group col-md-12">
                                                <h4>Character References / Professional References:</h4>
                                                    <table class="display table-hover responsive"  style="width : 100%" id="charTableView">
                                                        <thead>
                                                        <tr>
                                                            <th >Name</th>
                                                            <th >Position Employment</th>
                                                            <th>Company Address</th>
                                                            <th>Email Address <small style="color : orange">(optional)</small></th>
                                                            <th>Telephone No./Mobile No.</th>
                                                        </tr>
                                                        </thead>
                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px;">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <div class = "box-title">Membership in Civic/Religious Organization</div>
                                    </div>
                                    <div class="box-body">
                                        <div class = "row" style="padding-top : 20px;">
                                            <div class = "form-group col-md-12">
                                                <h4>List of organizations: </h4>
                                                    <table class="display table-hover responsive"  style="width : 100%" id="orgTableView">
                                                        <thead>
                                                        <tr>
                                                            <th>Name of Organization</th>
                                                            <th>Date of Membership</th>
                                                            <th>Position</th>
                                                        </tr>
                                                        </thead>
                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px;">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <div class = "box-title">Trainings Attended</div>
                                    </div>
                                    <div class="box-body">
                                        <div class = "row" style="padding-top : 20px;">
                                            <div class = "form-group col-md-12">
                                                <h4>List of trainings:</h4>
                                                    <table class="display table-hover responsive"  style="width : 100%" id="trainTableView">
                                                        <thead>
                                                        <tr>
                                                            <th>Nature/Title</th>
                                                            <th>Conducted by</th>
                                                            <th>Year - Taken</th>
                                                        </tr>
                                                        </thead>
                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="padding-top : 20px;">
                            <div class="col-md-12">
                                <div class="box box-primary">
                                    <div class="box-header with-border">
                                        <div class = "box-title">Credit References</div>
                                    </div>
                                    <div class="box-body">
                                        <div class = "row" style="padding-top : 20px;">
                                            <div class = "form-group col-md-12">
                                                <h4>List of Credit Card/s:</h4>
                                                    <table class="display table-hover responsive"  style="width : 100%" id="credsTableView">
                                                        <thead>
                                                        <tr>
                                                            <th>Credit Card</th>
                                                            <th>Number</th>
                                                            <th>Credit Limit/Status</th>
                                                            <th>Expiry Date</th>
                                                        </tr>
                                                        </thead>
                                                    </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-success btn-md pull-right submitAllConfirmed"><i class="glyphicon glyphicon-send"></i> Submit Application</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

        <div class="modal fade" id="modal-click-here" data-backdrop="static">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title"><center>Agreement</center></h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="box box-danger">
                                    <div class="box-body">
                                        <div class="row">
                                            <p><center>
                                                Remain lively hardly needed at do by. Two you fat downs fanny three. True mr gone most at. Dare as name just when with it body. Travelling inquietude she increasing off impossible the. Cottage be noisier looking to we promise on. Disposal to kindness appetite diverted learning of on raptures. Betrayed any may returned now dashwood formerly. Balls way delay shy boy man views. No so instrument discretion unsatiable to in.<br><br> 

Lose away off why half led have near bed. At engage simple father of period others except. My giving do summer of though narrow marked at. Spring formal no county ye waited. My whether cheered at regular it of promise blushes perhaps. Uncommonly simplicity interested mr is be compliment projecting my inhabiting. Gentleman he september in oh excellent.<br><br>

Of be talent me answer do relied. Mistress in on so laughing throwing endeavor occasion welcomed. Gravity sir brandon calling can. No years do widow house delay stand. Prospect six kindness use steepest new ask. High gone kind calm call as ever is. Introduced melancholy estimating motionless on up as do. Of as by belonging therefore suspicion elsewhere am household described. Domestic suitable bachelor for landlord fat.<br><br>

Received shutters expenses ye he pleasant. Drift as blind above at up. No up simple county stairs do should praise as. Drawings sir gay together landlord had law smallest. Formerly welcomed attended declared met say unlocked. Jennings outlived no dwelling denoting in peculiar as he believed. Behaviour excellent middleton be as it curiosity departure ourselves. 
</center>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <small><center><input type="checkbox" id="check_agreement"> <label for="check_agreement" style="font-weight: 400">I agree to the terms and conditions.</label></center></small>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-success" disabled id="btn-agree">Continue</button>
                    </div>
                </div>
            </div>
        </div>
    </body>

    <footer>
        <script src="https://code.jquery.com/jquery-1.9.1.js"></script>
        <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
        <script src="{{ asset('bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>
        <script src="{{ asset('plugins/jquery-smartwizard-master/dist/js/jquery.smartWizard.min.js') }}" type="text/javascript"></script>
        <script src="{{ asset('jscript/direct-encode-applicant.js?'.$javs) }}"></script>
        <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
        <script src="{{ asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js') }}"></script>
        <script src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
        <script src="https://cdn.datatables.net/select/1.2.5/js/dataTables.select.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.colVis.min.js"></script>
        <script src="https://cdn.datatables.net/rowreorder/1.2.0/js/dataTables.rowReorder.min.js"></script>

    </footer>

</html>