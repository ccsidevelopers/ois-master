<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Down extends Model
{
    //
}
