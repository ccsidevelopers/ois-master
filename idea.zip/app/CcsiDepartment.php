<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CcsiDepartment extends Model
{
    //
}
