<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bi_log extends Model
{
    //
}
