<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bi_endorsements_user extends Model
{
    //
}
