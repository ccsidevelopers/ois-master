<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeOfSubject extends Model
{
    //
}
