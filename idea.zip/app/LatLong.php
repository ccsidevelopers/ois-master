<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LatLong extends Model
{
    //
}
