<html>
<head>
    <script src="{{ asset('bower_components/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('bower_components/jquery-ui/jquery-ui.min.js') }}"></script>

    <title>offline checker</title>
</head>
<body>
<div class="content-wrapper">

 qqqq
</div>
<script src="{{ asset('jscript/offlinechecker.js') }}"></script>
</body>
</html>