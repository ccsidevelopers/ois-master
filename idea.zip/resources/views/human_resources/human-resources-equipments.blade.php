<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            EQUIPMENT MONITORING
        </h1>
    </section>
    <section class = "content">

        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
                <li class="active"><a id="tab1" href="#tab_eqMon1" data-toggle="tab" class = "human_resources_eq_class">Requesting of Items</a></li>
                <li><a id="tab3" href="#tab_eqMon2" data-toggle="tab" class = "human_resources_eq_class">List of Assigned Items</a></li>
                <li><a id="tab4" href="#tab_eqMon3" data-toggle="tab" class = "human_resources_eq_class">tab sample</a></li>
            </ul>
            <div class = "tab-content">
                <div class="tab-pane active" id="tab_eqMon1">


                </div>

                <div class = "tab-pane" id = "tab_eqMon2">


                </div>
                <div class = "tab-pane" id = "tab_eqMon3">

                </div>
            </div>
        </div>


    </section>
</div>